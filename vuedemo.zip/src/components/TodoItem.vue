<script>
import TodoCard from "./TodoCard.vue";
export default {
  components: {
    TodoCard,
  },
  data() {
    return {
      todos: [],
      text: "",
    };
  },
  methods: {
    increment() {
      this.todos.push({
        text: this.text,
        id: this.todos.length + 1,
        completed: false,
        editable: false,
      });
      this.text = "";
    },
    filterTodos(ID) {
      console.log(ID, "ID");
      this.todos = this.todos.filter((item) => item.id !== ID);
    },
    changeStatus(ID) {
      this.todos = this.todos.map((item) =>
        item.id === ID ? { ...item, editable: !item.editable } : item
      );
    },
    update(updatedText) {
      this.todos = this.todos.map((item) => ({ ...item, text: updatedText }));
    },
    complete(ID) {
      this.todos = this.todos.map((item) =>
        item.id === ID ? { ...item, completed: !item.completed } : item
      );
    },
  },
};
</script>
<template>
  <div>
    <div class="form">
      <form @submit.prevent="increment">
        <input class="input" v-model="text" />
        <button class="button" type="submit">
          Enter
        </button>
      </form>
    </div>
    <TodoCard
      v-for="todo in todos"
      :todo="todo"
      :remove="filterTodos"
      :changeStatus="changeStatus"
      :update="update"
      :complete="complete"
    />
  </div>
</template>
<style>
.input {
  padding: 8px 20px;
  margin: 4px 0;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}
.button {
  border: none;
  background-color: red;
  color: white;
  border-radius: 8px;
  padding: 10px;
}
.button:hover {
  border: 1px solid red;
  outline: none;
  background-color: white;
  color: red;
}
.form {
  align-items: center;
  display: flex;
  justify-content: center;
}
.todo-item {
  display: flex;
  width: 100%;
  margin: 20px;
}
</style>
