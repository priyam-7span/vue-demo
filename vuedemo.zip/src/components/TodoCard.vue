<script>
export default {
  props: {
    todo: Object,
    remove: Function,
    changeStatus: Function,
    update: Function,
    complete: Function,
  },
};
</script>
<template>
  <div class="flex-center">
    <div class="todo-item">
      <input type="checkbox" class="checker" @change="complete(todo.id)" />
      <input v-if="todo.editable" v-model="todo.text" />
      <p v-else :class="{ textChecked: todo.completed }">{{ todo.text }}</p>
      <div class="button-div">
        <button class="button-img" @click="changeStatus(todo.id)">
          <img src="../assets/edit.png" class="img-button" />
        </button>
        <button class="button-img" @click="remove(todo.id)">
          <img src="../assets/delete.png" class="img-button" />
        </button>
      </div>
    </div>
  </div>
</template>
<style scoped>
.textChecked {
  text-decoration: line-through;
}
.flex-center {
  display: flex;
  justify-content: center;
}
.button-div {
  display: flex;
  height: 100%;
}
.todo-item {
  max-width: 500px;
  display: flex;
  margin: 20px;
  justify-content: space-between;
  height: 40px;
}

.checker {
  width: 1.3em;
  height: 1.3em;
  background-color: white;
  border-radius: 50%;
  vertical-align: middle;
  border: 1px solid #ddd;
  appearance: none;
  -webkit-appearance: none;
  outline: none;
  cursor: pointer;
}
.checker:checked {
  background-color: red;
}
.img-button {
  height: 100%;
}
.button-img {
  background: none;
  border: none;
  cursor: pointer;
}
</style>
