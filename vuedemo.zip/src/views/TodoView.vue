<script>
export default {
  components: {
    TodoItem,
  },
};
import TodoItem from "@/components/TodoItem.vue";
</script>
<template>
  <TodoItem />
</template>
